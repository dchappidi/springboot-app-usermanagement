package zip;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity // Entity definition
public class User {

	private String name;
	
	@Column(unique = true)
	private String email;

	private Integer salary;

	private Integer expenses;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	public Integer getExpenses() {
		return expenses;
	}

	public void setExpenses(Integer expenses) {
		this.expenses = expenses;
	}
}
